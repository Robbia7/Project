﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebTest
{
    public class DatiJson
    {
    }

    public class jSonOutput
    {
        public string jsonrpc { get; set; }
        public int id { get; set; }
        public Result result { get; set; }
    }

    public class Result
    {
        public List<Price> prices { get; set; }
    }

    public class Price
    {
        public string dateISO8601 { get; set; }
        public double price { get; set; }
    }

    public class PriceDate
    {
        public string Date { get; set; }
        public double price { get; set; }
    }


    public class jSonInput
    {
        public int id { get; set; }
        public string jsonrpc { get; set; }
        public string method { get; set; }
        public Params _params { get; set; }
    }

    public class Params
    {
        public string startDateISO8601 { get; set; }
        public string endDateISO8601 { get; set; }
    }


}