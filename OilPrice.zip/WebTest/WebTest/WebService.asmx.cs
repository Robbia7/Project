﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.Services.Description;

namespace WebTest
{
    /// <summary>
    /// Descrizione di riepilogo per WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Per consentire la chiamata di questo servizio Web dallo script utilizzando ASP.NET AJAX, rimuovere il commento dalla riga seguente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public string GetOilPriceTrend(string jsonData)
        {
            try
            {
                jSonInput jIn = new jSonInput();
                System.Web.Script.Serialization.JavaScriptSerializer si = new System.Web.Script.Serialization.JavaScriptSerializer();
                jIn = si.Deserialize<jSonInput>(jsonData);

                string dataStart = "1988-12-04", dataEnd = "1988-12-08";
                dataStart = jIn._params.startDateISO8601;
                dataEnd = jIn._params.endDateISO8601;
                //string o1 = File.ReadAllText(@"C:\Temp\j3.txt");

                string jsonAll = new System.Net.WebClient().DownloadString("https://datahub.io/core/oil-prices/r/brent-daily.json");

                //AllPrices all= si.Deserialize(o1);
                List<PriceDate> all = si.Deserialize<List<PriceDate>>(jsonAll);
                int indice = 0, indiceStart = 0, indiceEnd = 0;
                foreach (PriceDate elem in all)
                {
                    DateTime d1 = DateTime.Parse(dataStart);
                    DateTime d2 = DateTime.Parse(elem.Date);
                    if (indiceStart == 0 && d2 >= d1)
                        indiceStart = indice;

                    DateTime d3 = DateTime.Parse(dataEnd);
                    if (indiceStart > 0 && d2 >= d3)
                    {
                        indiceEnd = indice;
                        break;
                    }
                    indice++;
                }
                //int indiceStart = all.Select((elem,index) => new { elem, index }).First(p=> p.elem.Date>=dataStart)
                // int indiceEnd = all.FindIndex(x => x.Date == dataEnd);

                jSonOutput jOut = new jSonOutput();
                jOut.jsonrpc = "2.0";
                jOut.id = 1;
                jOut.result = new Result();
                jOut.result.prices = new List<Price>();

                for (int i = indiceStart; i <= indiceEnd; i++)
                {
                    PriceDate tmpDate;
                    tmpDate = all.ElementAt(i);

                    Price tmpPrezzo = new Price();
                    tmpPrezzo.dateISO8601 = tmpDate.Date;
                    tmpPrezzo.price = tmpDate.price;

                    jOut.result.prices.Add(tmpPrezzo);

                }

                string returnJson = si.Serialize(jOut);

                return returnJson;
            }
            catch(Exception ex)
            {
                return "Errore : " +ex.Message;
            }
        }
    }
}
