﻿Imports System.ServiceModel
Imports System.Web.Script.Serialization

Public Class Form1
    Private Sub btnInvio_Click(sender As Object, e As EventArgs) Handles btnInvio.Click
        innvioJson()
    End Sub

    Public Sub innvioJson()

        Dim sAddressWs As String
        sAddressWs = "https://localhost:44323/WebService.asmx"
        Dim serializzato As String = ""
        Dim serializer As New JavaScriptSerializer
        Try
            Dim address As New EndpointAddress(sAddressWs)
            Dim binding As New BasicHttpsBinding()
            binding.MaxReceivedMessageSize = 65536 * 1000
            binding.MaxBufferSize = 65536 * 1000
            binding.MaxBufferPoolSize = 65536 * 1000
            binding.ReaderQuotas.MaxStringContentLength = 1000000000
            binding.ReaderQuotas.MaxArrayLength = 100000000


            Dim objJson As New clsJson()
            objJson.id = "1"
            objJson.jsonRpc = "2.0"
            objJson.method = "GetOilPriceTrend"
            objJson._params = New clsParams()
            Dim dStart As DateTime = dtpkStart.Value
            Dim strDa As String = dStart.Date.ToString("yyyy-MM-dd")
            Dim dEnd As DateTime = dtpkEnd.Value
            Dim strA As String = dEnd.Date.ToString("yyyy-MM-dd")
            objJson._params.startDateISO8601 = strDa
            objJson._params.endDateISO8601 = strA
            ' serJson = JsonConvert.SerializeObject(objJson)


            serializzato = serializer.Serialize(objJson)
            Dim ws As New WebService.WebServiceSoapClient(binding, address)
            Dim stringRisultato As String = ""
            'Dim output As New Output

            txtInput.Text = serializzato

            stringRisultato = ws.GetOilPriceTrend(serializzato)

            If stringRisultato.Contains("Errore") = False Then



                Dim outJson As New jSonOutput
                Dim si As New JavaScriptSerializer
                outJson = si.Deserialize(Of jSonOutput)(stringRisultato)

                Dim lstOut As New List(Of DatiOut)
                Dim tmpOut As DatiOut
                For Each ele In outJson.result.prices
                    tmpOut = New DatiOut
                    Dim dt As Date
                    dt = Date.Parse(ele.dateISO8601).ToShortDateString
                    tmpOut.pData = dt
                    tmpOut.pPrezzo = ele.price

                    lstOut.Add(tmpOut)
                Next


                grdOutput.DataSource = New List(Of DatiOut)
                grdOutput.DataSource = lstOut

            End If
            ' output = deserializeObject(stringRisultato)
            txtOutput.Text = stringRisultato
        Catch ex As Exception
            MsgBox("error : " + ex.Message)
        End Try

    End Sub
End Class
