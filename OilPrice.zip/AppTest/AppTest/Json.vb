﻿Public Class clsJson



    Public id As String
    Public jsonRpc As String
    Public method As String
    Public _params As clsParams


End Class
Public Class clsParams
    Public startDateISO8601 As String
    Public endDateISO8601 As String
End Class

Public Class jSonOutput
    Public jsonrpc As String
    Public id As Integer
    Public result As Result
End Class

Public Class Result

    Public prices As List(Of Price)
End Class


Public Class Price

    Public dateISO8601 As String
    Public price As Double
End Class


Public Class DatiOut
    Property pData As Date
    Property pPrezzo As Double
End Class