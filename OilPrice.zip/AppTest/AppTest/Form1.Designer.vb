﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnInvio = New System.Windows.Forms.Button()
        Me.dtpkStart = New System.Windows.Forms.DateTimePicker()
        Me.dtpkEnd = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.grdOutput = New System.Windows.Forms.DataGridView()
        Me.Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prezzo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.grdOutput, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnInvio
        '
        Me.btnInvio.BackColor = System.Drawing.Color.LightGreen
        Me.btnInvio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInvio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInvio.Location = New System.Drawing.Point(577, 43)
        Me.btnInvio.Name = "btnInvio"
        Me.btnInvio.Size = New System.Drawing.Size(157, 37)
        Me.btnInvio.TabIndex = 0
        Me.btnInvio.Text = "Invia Richiesta"
        Me.btnInvio.UseVisualStyleBackColor = False
        '
        'dtpkStart
        '
        Me.dtpkStart.CustomFormat = "dd/MM/yyyy"
        Me.dtpkStart.Location = New System.Drawing.Point(86, 52)
        Me.dtpkStart.Name = "dtpkStart"
        Me.dtpkStart.Size = New System.Drawing.Size(200, 20)
        Me.dtpkStart.TabIndex = 1
        '
        'dtpkEnd
        '
        Me.dtpkEnd.Location = New System.Drawing.Point(335, 52)
        Me.dtpkEnd.Name = "dtpkEnd"
        Me.dtpkEnd.Size = New System.Drawing.Size(200, 20)
        Me.dtpkEnd.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(56, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Da :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(311, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "a :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(56, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Selezionare intervallo di date :"
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(59, 107)
        Me.txtInput.Multiline = True
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(271, 608)
        Me.txtInput.TabIndex = 6
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(357, 107)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(377, 608)
        Me.txtOutput.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(56, 91)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "File Json Input"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(363, 91)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "File Json Output"
        '
        'grdOutput
        '
        Me.grdOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdOutput.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Data, Me.Prezzo})
        Me.grdOutput.Location = New System.Drawing.Point(765, 107)
        Me.grdOutput.Name = "grdOutput"
        Me.grdOutput.Size = New System.Drawing.Size(240, 608)
        Me.grdOutput.TabIndex = 10
        '
        'Data
        '
        Me.Data.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Data.DataPropertyName = "pData"
        Me.Data.HeaderText = "Data"
        Me.Data.Name = "Data"
        '
        'Prezzo
        '
        Me.Prezzo.DataPropertyName = "pPrezzo"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Prezzo.DefaultCellStyle = DataGridViewCellStyle1
        Me.Prezzo.FillWeight = 50.0!
        Me.Prezzo.HeaderText = "Prezzo €"
        Me.Prezzo.Name = "Prezzo"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1074, 727)
        Me.Controls.Add(Me.grdOutput)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpkEnd)
        Me.Controls.Add(Me.dtpkStart)
        Me.Controls.Add(Me.btnInvio)
        Me.Name = "Form1"
        Me.Text = "OilPrice"
        CType(Me.grdOutput, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnInvio As Button
    Friend WithEvents dtpkStart As DateTimePicker
    Friend WithEvents dtpkEnd As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents txtOutput As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents grdOutput As DataGridView
    Friend WithEvents Data As DataGridViewTextBoxColumn
    Friend WithEvents Prezzo As DataGridViewTextBoxColumn
End Class
